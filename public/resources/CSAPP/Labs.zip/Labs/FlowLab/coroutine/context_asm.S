.text

.globl __ctx_save
__ctx_save:
endbr64

    mov %rbp, 0(%rdi)
    mov %rbx, 8(%rdi)
    mov %r12, 16(%rdi)
    mov %r13, 24(%rdi)
    mov %r14, 32(%rdi)
    mov %r15, 40(%rdi)

    mov (%rsp), %rax 
    mov %rax, 56(%rdi)

    lea 8(%rsp), %rax
    mov %rax, 48(%rdi)
    xor %eax, %eax
    ret

.globl __ctx_restore
__ctx_restore:
    endbr64
    mov %rsi, %rax

    mov 0(%rdi), %rbp
    mov 8(%rdi), %rbx
    mov 16(%rdi), %r12
    mov 24(%rdi), %r13
    mov 32(%rdi), %r14
    mov 40(%rdi), %r15

    mov 48(%rdi), %rcx

    mov 56(%rdi), %rdx

    mov %rbx, %rdi

    mov %rcx, %rsp

    push %rdx
    ret
    
#ifdef __ELF__
.section .note.GNU-stack,"",@progbits
#endif
