#include <stdio.h>

int main()
{
    printf("hello Reed2006\n");
    // @TODO: print a sentence you want.
    printf("Hello, world!\n");
}