#include "cachelab.h"
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "csim.h"

// cache state and LRU clock (students will use them in their implementation)
static CacheSim cacheSim = {0};
static unsigned long long accessClock = 0;
static int sProvided = 0, eProvided = 0, bProvided = 0, tProvided = 0;

// print usage info
void usage(void)
{
    printf("Usage: ./csim [-hv] -s <num> -E <num> -b <num> -t <file> [-m <num>]\n");
    printf("Options:\n");
    printf("  -h         Print this help message.\n");
    printf("  -v         Optional verbose flag.\n");
    printf("  -s <num>   Number of set index bits (s), so S = 2^s sets.\n");
    printf("  -E <num>   Number of lines per set (E).\n");
    printf("  -b <num>   Number of block offset bits (b), so B = 2^b bytes per line.\n");
    printf("  -t <file>  Trace file.\n");
    printf("  -m <num>   Address width in bits (m), defaults to 64; must satisfy m > s + b.\n");
    printf("\n");
    printf("Examples:\n");
    printf("  linux>  ./csim -s 4 -E 1 -b 4 -t traces/yi.trace\n");
    printf("  linux>  ./csim -v -s 8 -E 2 -b 4 -t traces/yi.trace\n");
    exit(1);
}

// parse command line and get the parameters
void parseline(int argc, char **argv)
{
    int opt;
    int num = 0;
    mBits = 64; // default address width
    while ((opt = getopt(argc, argv, "hvs:E:b:t:m:")) != -1)
    {
        switch (opt)
        {
        case 'h':
            usage();
            break;
        case 'v':
            verbose = 1;
            break;
        case 's':
            num = atoi(optarg);
            if (optarg[0] == '\0' || num < 0)
            {
                printf("./csim: Missing required command line argument\n");
                usage();
            }
            sBits = num;
            sProvided = 1;
            break;
        case 'E':
            num = atoi(optarg);
            if (optarg[0] == '\0' || num <= 0)
            {
                printf("./csim: Missing required command line argument\n");
                usage();
            }
            associativity = num;
            eProvided = 1;
            break;
        case 'b':
            num = atoi(optarg);
            if (optarg[0] == '\0' || num < 0)
            {
                printf("./csim: Missing required command line argument\n");
                usage();
            }
            bBits = num;
            bProvided = 1;
            break;
        case 't':
            strncpy(filePath, optarg, sizeof(filePath) - 1);
            filePath[sizeof(filePath) - 1] = '\0';
            tProvided = 1;
            break;
        case 'm':
            num = atoi(optarg);
            if (optarg[0] == '\0' || num <= 0)
            {
                printf("./csim: Missing required command line argument\n");
                usage();
            }
            mBits = num;
            break;
        case ':':
            printf("./csim: Missing required command line argument\n");
            usage();
            break;
        case '?':
            usage();
            break;
        default:
            printf("getopt error");
            exit(1);
            break;
        }
    }

    if (!(sProvided && eProvided && bProvided && tProvided))
    {
        printf("./csim: Missing required command line argument\n");
        usage();
    }

    if (mBits <= sBits + bBits)
    {
        fprintf(stderr, "./csim: Address width must satisfy m > s + b\n");
        exit(1);
    }

    numSets = 1ULL << sBits;
    blockSize = 1ULL << bBits;
}

void initCache(void){
    // TODO: Student implementation — allocate the cache structure and initialize valid bits and timestamps
    cacheSim.setCount = numSets;
    cacheSim.linesPerSet = associativity;
    cacheSim.sets = (CacheSet *)malloc(numSets * sizeof(CacheSet));
    for(size_t i = 0; i < numSets; i++)
    {
        cacheSim.sets[i].lines = (CacheLine*) malloc (associativity * sizeof(CacheLine));
        for(size_t j = 0; j < associativity; j++)
        {
            cacheSim.sets[i].lines[j].valid = 0;
            cacheSim.sets[i].lines[j].tag = 0;
            cacheSim.sets[i].lines[j].lruStamp = 0;
        }
    }
}

void freeCache(void){
    // TODO: Student implementation — free any allocated memory
    for(size_t i = 0; i < cacheSim.setCount; i++)
    {
        free(cacheSim.sets[i].lines);
    }
    free(cacheSim.sets);
}

int accessCache(unsigned long long address){
    // TODO: Student implementation — perform one access using (S, E, B) with LRU and return hit/miss/evict flags
    size_t setIndex = (address >> bBits) & ((1 << sBits) - 1);
    unsigned long long tag = address >> (bBits + sBits);
    CacheSet *set = &cacheSim.sets[setIndex];
    accessClock++;
    // Check for hit
    CacheLine *emptyLine = NULL;
    for(size_t i = 0; i < cacheSim.linesPerSet; i++)
    {
        CacheLine *line = &set->lines[i];
        if(line->valid && line->tag == tag)
        {
            line->lruStamp = accessClock;
            hits++;
            return ACCESS_RESULT_HIT;
        }
        if(!line->valid && emptyLine == NULL)
        {
            emptyLine = line;
        }
    }

    if(emptyLine != NULL)
    {
        emptyLine->valid = 1;
        emptyLine->tag = tag;
        emptyLine->lruStamp = accessClock;
        misses++;
        return ACCESS_RESULT_MISS;
    }

    size_t lruIndex = 0;
    unsigned long long minStamp = ULLONG_MAX;
    for(size_t j = 0; j < cacheSim.linesPerSet; j++)
    {
        if(set->lines[j].lruStamp < minStamp)
        {
            minStamp = set->lines[j].lruStamp;
            lruIndex = j;
        }
    }

    set->lines[lruIndex].tag = tag;
    set->lines[lruIndex].lruStamp = accessClock;
    misses++;
    evictions++;
    return ACCESS_RESULT_MISS | ACCESS_RESULT_EVICT;
}

void printVerboseResult(int result){
    if (result & ACCESS_RESULT_HIT){
        printf(" hit");
    }
    if (result & ACCESS_RESULT_MISS){
        printf(" miss");
    }
    if (result & ACCESS_RESULT_EVICT){
        printf(" eviction");
    }
}

void simulateTrace(void)
{
    FILE *trace = fopen(filePath, "r");
    if (!trace){
        fprintf(stderr, "Error opening trace file %s: %s\n", filePath, strerror(errno));
        exit(1);
    }

    char buffer[256];
    while (fgets(buffer, sizeof(buffer), trace)){
        char op = '\0';
        unsigned long long address = 0;
        int size = 0;

        if (sscanf(buffer, " %c %llx,%d", &op, &address, &size) != 3){
            continue;
        }

        if (op == 'I'){
            continue;
        }

        if (verbose){
            printf("%c %llx,%d", op, address, size);
        }

        int outcome = accessCache(address);

        if (op == 'M'){
            int secondOutcome = accessCache(address);
            if (verbose){
                printVerboseResult(outcome);
                printVerboseResult(secondOutcome);
                printf("\n");
            }
        }
        else{
            if (verbose){
                printVerboseResult(outcome);
                printf("\n");
            }
        }
    }

    fclose(trace);
}

int main(int argc, char *argv[]){
    parseline(argc, argv);
    initCache();
    simulateTrace();
    freeCache();
    printSummary(hits, misses, evictions);
    return 0;
}
