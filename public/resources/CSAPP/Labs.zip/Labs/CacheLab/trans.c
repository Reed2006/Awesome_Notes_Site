/*
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/*
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded.
 */

char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    int a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11;

    if (M == 48 && N == 48)
    {
        for (int i = 0; i < 48; i += 12)
            for (int j = 0; j < 48; j += 12)
                for (int k = i; k < i + 12; k++)
                {
                    a0 = A[k][j];
                    a1 = A[k][j + 1];
                    a2 = A[k][j + 2];
                    a3 = A[k][j + 3];
                    a4 = A[k][j + 4];
                    a5 = A[k][j + 5];
                    a6 = A[k][j + 6];
                    a7 = A[k][j + 7];
                    a8 = A[k][j + 8];
                    a9 = A[k][j + 9];
                    a10 = A[k][j + 10];
                    a11 = A[k][j + 11];

                    // 2. 将寄存器值写入 B 的一列
                    B[j][k] = a0;
                    B[j + 1][k] = a1;
                    B[j + 2][k] = a2;
                    B[j + 3][k] = a3;
                    B[j + 4][k] = a4;
                    B[j + 5][k] = a5;
                    B[j + 6][k] = a6;
                    B[j + 7][k] = a7;
                    B[j + 8][k] = a8;
                    B[j + 9][k] = a9;
                    B[j + 10][k] = a10;
                    B[j + 11][k] = a11;
                }
    }

    else if (M == 96 && N == 96)
    {
        for (int i = 0; i < 96; i += 12)
            for (int j = 0; j < 96; j += 12)
            {
                for (int x = i; x < i + 6; ++x)
                {
                    a0 = A[x][j];
                    a1 = A[x][j + 1];
                    a2 = A[x][j + 2];
                    a3 = A[x][j + 3];
                    a4 = A[x][j + 4];
                    a5 = A[x][j + 5];
                    a6 = A[x][j + 6];
                    a7 = A[x][j + 7];
                    a8 = A[x][j + 8];
                    a9 = A[x][j + 9];
                    a10 = A[x][j + 10];
                    a11 = A[x][j + 11];

                    B[j][x] = a0;
                    B[j + 1][x] = a1;
                    B[j + 2][x] = a2;
                    B[j + 3][x] = a3;
                    B[j + 4][x] = a4;
                    B[j + 5][x] = a5;

                    // 写入 B 右上 (临时存放)
                    B[j][x + 6] = a6;
                    B[j + 1][x + 6] = a7;
                    B[j + 2][x + 6] = a8;
                    B[j + 3][x + 6] = a9;
                    B[j + 4][x + 6] = a10;
                    B[j + 5][x + 6] = a11;
                }

                for (int y = j; y < j + 6; ++y)
                {
                    a0 = A[i + 6][y];
                    a1 = A[i + 7][y];
                    a2 = A[i + 8][y];
                    a3 = A[i + 9][y];
                    a4 = A[i + 10][y];
                    a5 = A[i + 11][y];

                    // 读取 B 右上 (之前暂存的数据) -> a6-a11
                    a6 = B[y][i + 6];
                    a7 = B[y][i + 7];
                    a8 = B[y][i + 8];
                    a9 = B[y][i + 9];
                    a10 = B[y][i + 10];
                    a11 = B[y][i + 11];

                    B[y][i + 6] = a0;
                    B[y][i + 7] = a1;
                    B[y][i + 8] = a2;
                    B[y][i + 9] = a3;
                    B[y][i + 10] = a4;
                    B[y][i + 11] = a5;

                    B[y + 6][i] = a6;
                    B[y + 6][i + 1] = a7;
                    B[y + 6][i + 2] = a8;
                    B[y + 6][i + 3] = a9;
                    B[y + 6][i + 4] = a10;
                    B[y + 6][i + 5] = a11;
                }

                for (int x = i + 6; x < i + 12; ++x)
                {
                    a0 = A[x][j + 6];
                    a1 = A[x][j + 7];
                    a2 = A[x][j + 8];
                    a3 = A[x][j + 9];
                    a4 = A[x][j + 10];
                    a5 = A[x][j + 11];


                    B[j + 6][x] = a0;
                    B[j + 7][x] = a1;
                    B[j + 8][x] = a2;
                    B[j + 9][x] = a3;
                    B[j + 10][x] = a4;
                    B[j + 11][x] = a5;
                }
            }
    }
    else
    {
        // 针对 91x97 或其他不规则矩阵的处理 
        for (int j = 0; j < M / 12 * 12; j += 12)
            for (int i = 0; i < N / 12 * 12; ++i)
            {
                a0 = A[i][j];
                a1 = A[i][j + 1];
                a2 = A[i][j + 2];
                a3 = A[i][j + 3];
                a4 = A[i][j + 4];
                a5 = A[i][j + 5];
                a6 = A[i][j + 6];
                a7 = A[i][j + 7];
                a8 = A[i][j + 8];
                a9 = A[i][j + 9];
                a10 = A[i][j + 10];
                a11 = A[i][j + 11];

                B[j][i] = a0;
                B[j + 1][i] = a1;
                B[j + 2][i] = a2;
                B[j + 3][i] = a3;
                B[j + 4][i] = a4;
                B[j + 5][i] = a5;
                B[j + 6][i] = a6;
                B[j + 7][i] = a7;
                B[j + 8][i] = a8;
                B[j + 9][i] = a9;
                B[j + 10][i] = a10;
                B[j + 11][i] = a11;
            }
        for (int i = N / 12 * 12; i < N; ++i)
            for (int j = M / 12 * 12; j < M; ++j)
            {
                a0 = A[i][j];
                B[j][i] = a0;
            }
        for (int i = 0; i < N; ++i)
            for (int j = M / 12 * 12; j < M; ++j)
            {
                a0 = A[i][j];
                B[j][i] = a0;
            }
        for (int i = N / 12 * 12; i < N; ++i)
            for (int j = 0; j < M; ++j)
            {
                a0 = A[i][j];
                B[j][i] = a0;
            }
    }
}
/*
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started.
 */

/*
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++)
    {
        for (j = 0; j < M; j++)
        {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }
}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc);

    /* Register any additional transpose functions */
    // registerTransFunction(trans, trans_desc);
}

/*
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++)
    {
        for (j = 0; j < M; ++j)
        {
            if (A[i][j] != B[j][i])
            {
                return 0;
            }
        }
    }
    return 1;
}