/* 
 * CS:APP Data Lab 
 * 
 * <Reed2006 24300680058>
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:

  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting if the shift amount
     is less than 0 or greater than 31.


EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implement floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants. You can use any arithmetic,
logical, or comparison operations on int or unsigned data.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operations (integer, logical,
     or comparison) that you are allowed to use for your implementation
     of the function.  The max operator count is checked by dlc.
     Note that assignment ('=') is not counted; you may use as many of
     these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */


#endif
#include "bits.h"

// P1
/* 
 * signMask - return a mask with only the most significant bit set (0x80000000)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 2
 *   Rating: 1
 */
int signMask(void) {
  return 1 << 31;
}

// P2
/* 
 * bitXor - x^y using only ~ and & 
 *   Example: bitXor(4, 5) = 1, bitXor(7, 7) = 0
 *   Legal ops: ~ &
 *   Max ops: 8
 *   Rating: 2
 */
int bitXor(int x, int y) {
	return ~(~(~x&y) & ~(x&~y));
}

// P3
/*
 * negativePart - return -x if x < 0, otherwise return 0
 *   Examples: negativePart(-10) = 10, negativePart(5) = 0
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 6
 *   Rating: 3
 */
int negativePart(int x){
  int neg = ~x + 1;
  int mask = x >> 31;
  return neg & mask;
}


// P4
/*
 * clearByte - return x with the nth byte cleared to 0
 *   You can assume 0 <= n <= 3
 *   Example: clearByte(0x01020304, 2) = 0x01000304
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 6
 *   Rating: 4
 */
int clearByte(int x,int n) {
  return x & ~(0xff << (n << 3));
}

// P5
/* 
 * roundUp - round up x to the nearest multiple of 256 that is bigger than x
 *   Example: roundUp(0x117f) = 0x1200
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 8
 *   Rating: 4
 */
int roundUp(int x) {
  return (x + 0xff) & ~0xff;
}

// P6
/* 
 * isLargerOrEqual - return 1 if x >= y, else return 0 
 *   Example: isLargerOrEqual(5,4) = 1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 4
 */
int isLargerOrEqual(int x, int y) {
  int sign_x = (x >> 31) & 0x01;
  int sign_y = (y >> 31) & 0x01;
  int sign_diff = sign_x ^ sign_y;
  int diff = x + (~y + 1);
  int sign_diff_xy = (diff >> 31) & 0x01;
  return (sign_diff & sign_y) | (!sign_diff & !sign_diff_xy);
}

// P7
/* 
 * logicalShift - shift x to the right by n bits, using a logical shift
 *   Can assume that 0 <= n <= 31
 *   Examples: logicalShift(0x87654321,4) = 0x08765432
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 */
int logicalShift(int x, int n) {
  return (x >> n) & (~((1 << 31) >> n << 1));
}

// P8
/*
 * swapNibblePairs - swap the low and high 4 bits within each byte of x
 *   Examples: swapNibblePairs(0xAB) = 0xBA
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 5
 */
int swapNibblePairs(int x) {
  int high_nibble = (x >> 4) & (0x0f | 0x0f << 8 | 0x0f << 16 | 0x0f << 24);
  int low_nibble = (x << 4) & (0xf0 | 0xf0 << 8 | 0xf0 << 16 | 0xf0 << 24);
  return high_nibble | low_nibble;
}

// P9
/*
 * secondLowestZeroBit - return a mask that marks the position of the second least significant 0 bit
 *   Examples: secondLowestZeroBit(0xFFFFFFFC) = 0x4, secondLowestZeroBit(0x7FFFFFFF) = 0
 *             secondLowestZeroBit(-1) = 0
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 8
 *   Rating: 5
 */
int secondLowestZeroBit(int x) {
  int invert_x = ~x;
  int new_x = invert_x & (invert_x + ~0);
  int secondleastzero = new_x & (~new_x + 1);
  return secondleastzero;
}

// P10
/* 
 * rotateRightBits - rotate x to right by n bits
 *   you can assume n >= 0
 *   Examples: rotateRightBits(0x12345678, 8) = 0x78123456
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 *   Rating: 5
 */
int rotateRightBits(int x, int n) {
  int shift_left = 32 + (~n + 1);
  int left_part = x << shift_left;
  int right_part = (x >> n) & ~(~0 << shift_left);
  return left_part | right_part;
}

// P11
/* 
 * fractions - return floor((x*5 + 8)/16) for 0 <= x <= (1 << 28), x is an integer 
 *   Example: fractions(20) = 6
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 8
 *   Rating: 5
 */
int fractions(int x) {
  return ((x << 2) + x + 8) >> 4;
}


// P12
/* 
 * overflowCalc - given binary representations of three 32-bit positive numbers and add them together, 
 *      return the binary representation of the part where bits are higher than 32.
 *   Examples: overflowCalc(0xffffffff, 0xffffffff, 0xffffffff) = 2
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 30
 *   Rating: 7 
 */
int overflowCalc(int x, int y, int z) {
  int mask1 = (x & y) | ((x ^ y) & ~(x + y));
  int sum_xy = x + y;
  int mask2 = (sum_xy & z) | ((sum_xy ^ z) & ~(sum_xy + z));
  return ((mask1 >> 31)&1) + ((mask2 >> 31)&1);
}

// P13
/* 
 * mul5Sat - return x*5, and if x*5 overflow, change the result to 
 * INT_MAX(0x7fffffff) or INT_MIN(0x80000000) correspondingly
 *   Examples: mul5Sat(1) = 0x5, mul5Sat(0x40000000) = 0x7fffffff
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 36
 *   Rating: 7
 */
int mul5Sat(int x) {
  int mul2 = x << 1;
  int mul4 = mul2 << 1;
  int mul5 = mul4 + x;
  int sign_x = (x >> 31);
  int sign_mul2 = (mul2 >> 31);
  int sign_mul4 = (mul4 >> 31);
  int sign_mul5 = (mul5 >> 31);
  int overflow = ((sign_x ^ sign_mul2) | (sign_mul2 ^ sign_mul4) | (sign_mul4 ^ sign_mul5));
  int limit = (~sign_x) ^ (1 << 31);
  return (overflow & limit) | (~overflow & mul5);
}

// P14
/* 
 * float_half - Return bit-level equivalent of expression f/2 for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer / unsigned operations incl. ||, &&. also if, while
 *   Max ops: 32
 *   Rating: 7
 */
unsigned float_half(unsigned f) {
  int sign = f & (1 << 31);
  int exp = f & (0xff << 23);
  int frac = f & ~(~0 << 23);
  int add_round;
  int exp_test = exp >> 23;
  if (exp_test == 0){
    add_round = (frac & 0x03) == 0x03;
    frac = (frac >> 1) + add_round;
    return sign | frac;
  }
  if (exp_test == 1){
    frac = (1 << 23) | frac;
    add_round = (frac & 0x03) == 0x03;
    frac = (frac >> 1) + add_round;
    return sign | frac;
  }
  if (exp_test == 0xff){
    return f;
  }
  exp_test = exp_test - 1;
  return sign | (exp_test << 23) | frac;
}

// P15
/* 
 * float_i2f - Return bit-level equivalent of expression (float) x.
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   Legal ops: Any integer / unsigned operations incl. ||, &&. also if, while
 *   Max ops: 40
 *   Rating: 7
 */
unsigned float_i2f(int x) {
  int max_exp_pos, exp, frac, add_round;
  int sign = x & (0x80000000);
  if (x == 0) return 0;
  if (x == 0x80000000) return sign | 0x4f000000;
  if (x < 0) x = -x;
  max_exp_pos = 31;
  while (((x >> max_exp_pos) & 0x01) == 0) max_exp_pos--;
  exp = max_exp_pos + 127;
  exp = exp << 23;
  if (max_exp_pos <= 23){
    frac = (x & ~(~0 << max_exp_pos)) << (23 - max_exp_pos);
    return sign | exp | frac;
  }
  else{
    int shift = max_exp_pos - 23;
    int half = 1 << (shift - 1);
    int remainder = x & ((1 << shift) - 1);
    frac = (x >> shift) & 0x7fffff;
    if(remainder > half || (remainder == half && (frac & 0x01))) add_round = 1;
    else add_round = 0;
    frac = frac + add_round;
    if (frac >> 23){
      exp = exp + 0x800000;
      frac = 0;
    }
    return sign | exp | frac;
  }
}


#ifdef NOT_SUPPOSED_TO_BE_DEFINED
#   __          __  _                          
#   \ \        / / | |                         
#    \ \  /\  / /__| | ___ ___  _ __ ___   ___ 
#     \ \/  \/ / _ \ |/ __/ _ \| '_ ' _ \ / _ \
#      \  /\  /  __/ | (_| (_) | | | | | |  __/       
#       \/  \/ \___|_|\___\___/|_| |_| |_|\___|
#                                              

#  ██╗  ██╗ ██████╗ ███╗   ██╗ ██████╗ ██████╗     ██████╗  █████╗ ██████╗ ████████╗
#  ██║  ██║██╔═══██╗████╗  ██║██╔═══██╗██╔══██╗    ██╔══██╗██╔══██╗██╔══██╗╚══██╔══╝
#  ███████║██║   ██║██╔██╗ ██║██║   ██║██████╔╝    ██████╔╝███████║██████╔╝   ██║   
#  ██╔══██║██║   ██║██║╚██╗██║██║   ██║██╔══██╗    ██╔═══╝ ██╔══██║██╔══██╗   ██║   
#  ██║  ██║╚██████╔╝██║ ╚████║╚██████╔╝██║  ██║    ██║     ██║  ██║██║  ██║   ██║   
#  ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   
#                                                                                   
#endif

// P16
/* 
 * float_inv - Return bit-level equivalent of expression 1/x (x is an integer) for
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   When x is 0, return NaN.
 *   Legal ops: Any integer / unsigned operations incl. ||, &&. also if, while
 *   Max ops: 120
 *   Rating: 10
 *   For mercy, x is between -16777216 and 16777216, meaning that you don't have
 *   to handle denormalized numbers.
 */
unsigned float_inv(int x) {
  int sign;
  int k = 0;
  int max_exp_pos = 0;
  int temp;
  int exp;
  unsigned d;
  unsigned q = 0;
  int i;
  unsigned temp_dividend;
  int frac;
  int add_round;

  if(x == 0) {
      return 0x7F800000;
  }
  sign = x & (1 << 31);
  if (x < 0) {
      x = ~x + 1;
  }
  if ((x & (x - 1)) == 0) {
    temp = x;
    while (temp > 1) {
      temp >>= 1;
      k++;
    }
    return sign | ((127 - k) << 23);
  }
  temp = x;
  while(temp > 0){
    max_exp_pos++;
    temp = temp >> 1;
  }
  max_exp_pos--;
  exp = 126 - max_exp_pos;
  d = x;
  temp_dividend = 1 << (max_exp_pos + 1);
  for (i = 0; i < 27; i++) {
  if(temp_dividend < d){
    temp_dividend = temp_dividend << 1;
    q = q << 1;
  }
  else{
    temp_dividend = (temp_dividend - d) << 1;
    q = (q << 1) + 1;
  }
  }
    if (temp_dividend != 0) {
    q |= 1;
  }
  frac = q >> 3;
  add_round = q & 0x07;
  if(add_round > 0x04 || (add_round == 0x04 && (frac & 0x01))){
    frac = frac + 1;
    if(frac == (1 << 24)){
      exp = exp + 1;
      frac = 0;
    }
  }
  return sign | (exp << 23) | (frac & ~(1 << 23));
}

// P17
/*
 * oddParity - return the odd parity bit of x, that is, 
 *      when the number of 1s in the binary representation of x is even, then the return 1, otherwise return 0.
 *   Examples: oddParity(5) = 1, oddParity(7) = 0
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 56
 *   Rating: 10
 */
int oddParity(int x) {
  int mask1, mask2, mask3, mask4, mask5;
  mask1 = 0x55 | (0x55 << 8);
  mask1 = mask1 | (mask1 << 16);
  mask2 = 0x33 | (0x33 << 8);
  mask2 = mask2 | (mask2 << 16);
  mask3 = 0x0F | (0x0F << 8);
  mask3 = mask3 | (mask3 << 16);
  mask4 = 0xFF | (0xFF << 16);
  mask5 = 0xFF | (0xFF << 8);
  x = (x & mask1) + ((x >> 1) & mask1);
  x = (x & mask2) + ((x >> 2) & mask2);
  x = (x & mask3) + ((x >> 4) & mask3);
  x = (x & mask4) + ((x >> 8) & mask4);
  x = (x & mask5) + ((x >> 16) & mask5);
  x = x & 0x01;
  x = ~x + 2;
  return x;
}

// P18
/*
 * bitCount - return count of number of 1's in the binary representation of x
 *   Examples: bitCount(5) = 2, bitCount(7) = 3
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 40
 *   Rating: 10
 */
int bitCount(int x) {
  int mask1, mask2, mask3, mask4, mask5;
  mask1 = 0x55 | (0x55 << 8);
  mask1 = mask1 | (mask1 << 16);
  mask2 = 0x33 | (0x33 << 8);
  mask2 = mask2 | (mask2 << 16);
  mask3 = 0x0F | (0x0F << 8);
  mask3 = mask3 | (mask3 << 16);
  mask4 = 0xFF | (0xFF << 16);
  mask5 = 0xFF | (0xFF << 8);

  x = (x & mask1) + ((x >> 1) & mask1);
  x = (x & mask2) + ((x >> 2) & mask2);
  x = (x & mask3) + ((x >> 4) & mask3);
  x = (x & mask4) + ((x >> 8) & mask4);
  x = (x & mask5) + ((x >> 16) & mask5);
  return x;
}

// P19
/*
 * bitReverse - Reverse bits in an 32-bit integer
 *   Examples: bitReverse(0x80000004) = 0x20000001
 *             bitReverse(0x7FFFFFFF) = 0xFFFFFFFE
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 34
 *   Rating: 10
 */
int bitReverse(int x)
{
  int msk1, msk2, msk3, msk4, msk5;
  msk1 = (0xff << 8) | 0xff;
  msk2 = (msk1 << 8) ^ msk1;
  msk3 = (msk2 << 4) ^ msk2;
  msk4 = (msk3 << 2) ^ msk3;
  msk5 = (msk4 << 1) ^ msk4;
  x = ((x >> 16) & msk1) | (x << 16);
  x = ((x >> 8) & msk2) | ((x & msk2) << 8);
  x = ((x >> 4) & msk3) | ((x & msk3) << 4);
  x = ((x >> 2) & msk4) | ((x & msk4) << 2);
  x = ((x >> 1) & msk5) | ((x & msk5) << 1);

  return x;
}
